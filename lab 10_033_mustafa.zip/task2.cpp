#include <iostream>
using namespace std;

int main() {
    int arr[8] = {2, 4, 5, 728, 901, 123, 345, 67};
    int size =8;
    int num;
    cout << "Enter a number to search: ";
    cin >> num;
    for (int i = 0; i < size; i++) {
        if (arr[i] == num) {
            cout << "Number " << num << " found at index " << i << "." << endl;
            return 0; 
        }
    }
    cout << "Number is not found." << endl;  

    return 0;
}
