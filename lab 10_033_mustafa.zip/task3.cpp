#include <iostream>
using namespace std;

void modified_array(int arr[], int size) {
    for (int i = 0;i < size;i++) {
        arr[i] *= 3;
    }

    cout << "modified array elements: ";
    for (int i = 0;i < size;i++) {
        cout << arr[i] << " ";
    }
}

int main() {
    int arr[10] = {2, 4, 3, 7, 11, 62, 77, 8, 94, 120};
    modified_array(arr, 10);
    return 0;
}
