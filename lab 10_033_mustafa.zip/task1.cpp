#include <iostream>
using namespace std;
int main(){
	int nums[10];
	int size=10;
	double avg=0;
	for(int i=0;i<size;i++){
		cout<<"enter the age";
	cin>>nums[i];
		(avg+=nums[i]);
	}
	avg=avg/size;
	cout<<"the average is"<<avg;
		return 0;
	}
